package com.conectdb.atividade.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conectdb.atividade.model.aluno;
import com.conectdb.atividade.repository.alunoRepository;

@Service
public class alunoService implements alunoRepository {

    @Autowired
    private alunoRepository aR;

    @Override
    public long count() {
        return aR.count();
    }

    @Override
    public void delete(aluno entity) {
        aR.delete(entity);
    }

    @Override
    public void deleteAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAll'");
    }

    @Override
    public void deleteAll(Iterable<? extends aluno> entities) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAll'");
    }

    @Override
    public void deleteAllById(Iterable<? extends Long> id_alunos) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAllById'");
    }

    @Override
    public void deleteById(Long id_aluno) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteById'");
    }

    @Override
    public boolean existsById(Long id_aluno) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'existsById'");
    }

    @Override
    public Iterable<aluno> findAll() {
        return aR.findAll();
    }

    @Override
    public Iterable<aluno> findAllById(Iterable<Long> id_alunos) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAllById'");
    }

    @Override
    public Optional<aluno> findById(Long id_aluno) {
       return aR.findById(id_aluno);
    }

    @Override
    public <S extends aluno> S save(S entity) {
        return aR.save(entity);
    }

    @Override
    public <S extends aluno> Iterable<S> saveAll(Iterable<S> entities) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'saveAll'");
    }

}
