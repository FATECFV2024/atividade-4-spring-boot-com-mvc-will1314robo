package com.conectdb.atividade.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.conectdb.atividade.service.notaService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.conectdb.atividade.model.nota;


@RestController
public class notaController {
    @Autowired
    private notaService ns;
    @GetMapping("/listarNot")
    public List<nota> listaNotas(){
        return (List<nota>) ns.findAll();
    }
    @PostMapping("/criarNot")
    public nota criarNotas(@RequestBody nota n){
        nota novo = ns.save(n);
        return novo;
    }
}
