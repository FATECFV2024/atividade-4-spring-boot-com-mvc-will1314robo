package com.conectdb.atividade.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.conectdb.atividade.service.alunoService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.conectdb.atividade.model.aluno;


@RestController
public class alunoController {
    @Autowired
    private alunoService as;
    @GetMapping("/listarAl")
    public List<aluno> listaAlunos(){
        return (List<aluno>) as.findAll();
    }
    @PostMapping("/criarAl")
    public aluno criarAluno(@RequestBody aluno a){
        aluno novo = as.save(a);
        return novo;
    }
}
