package com.conectdb.atividade.repository;

import org.springframework.data.repository.CrudRepository;

import com.conectdb.atividade.model.aluno;

public interface alunoRepository 
    extends CrudRepository <aluno,Long> {
    
}