package com.conectdb.atividade.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conectdb.atividade.model.endereco;
import com.conectdb.atividade.repository.enderecoRepository;

@Service
public class enderecoService implements enderecoRepository {

    @Autowired
    private enderecoRepository eR;

    @Override
    public long count() {
        return eR.count();
    }

    @Override
    public void delete(endereco entity) {
        eR.delete(entity);
    }

    @Override
    public void deleteAll() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAll'");
    }

    @Override
    public void deleteAll(Iterable<? extends endereco> entities) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAll'");
    }

    @Override
    public void deleteAllById(Iterable<? extends Long> id_ends) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAllById'");
    }

    @Override
    public void deleteById(Long id_end) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteById'");
    }

    @Override
    public boolean existsById(Long id_end) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'existsById'");
    }

    @Override
    public Iterable<endereco> findAll() {
        return eR.findAll();
    }

    @Override
    public Iterable<endereco> findAllById(Iterable<Long> id_ends) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAllById'");
    }

    @Override
    public Optional<endereco> findById(Long id_end) {
       return eR.findById(id_end);
    }

    @Override
    public <S extends endereco> S save(S entity) {
        return eR.save(entity);
    }

    @Override
    public <S extends endereco> Iterable<S> saveAll(Iterable<S> entities) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'saveAll'");
    }

}
