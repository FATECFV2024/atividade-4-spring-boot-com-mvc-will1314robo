package com.conectdb.atividade.repository;

import org.springframework.data.repository.CrudRepository;

import com.conectdb.atividade.model.nota;

public interface notaRepository 
    extends CrudRepository <nota,Long> {
    
}